-- ============================================================
--  Placar da Mesada — SQL v20: contas unificadas (pais + criança)
--  Rodar DEPOIS do supabase-fase2.sql. Idempotente.
-- ============================================================

-- Perfil do usuário logado: qual família e qual papel (pais/criança)
create or replace function meu_perfil()
returns table (familia_id uuid, tipo text, nome text)
language sql security definer stable set search_path = public as $$
  select familia_id, tipo, nome from perfis where user_id = auth.uid() limit 1
$$;

-- Pais vinculam a conta da criança (criada no app) à própria família
create or replace function vincular_crianca(p_user_id uuid, p_nome text)
returns void language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  select familia_id into fid from perfis where user_id = auth.uid() and tipo = 'pais' limit 1;
  if fid is null then raise exception 'Somente os pais podem vincular uma criança'; end if;
  insert into perfis (familia_id, user_id, tipo, nome)
    values (fid, p_user_id, 'crianca', p_nome)
    on conflict do nothing;
end $$;

-- Pais redefinem a senha da criança (a criança não tem e-mail para "esqueci a senha")
create extension if not exists pgcrypto with schema extensions;
create or replace function redefinir_senha_crianca(p_nova text)
returns void language plpgsql security definer set search_path = public, extensions as $$
declare fid uuid; cid uuid;
begin
  if length(p_nova) < 6 then raise exception 'Senha muito curta'; end if;
  select familia_id into fid from perfis where user_id = auth.uid() and tipo = 'pais' limit 1;
  if fid is null then raise exception 'Somente os pais podem redefinir'; end if;
  select user_id into cid from perfis where familia_id = fid and tipo = 'crianca' limit 1;
  if cid is null then raise exception 'Criança não encontrada'; end if;
  update auth.users set encrypted_password = extensions.crypt(p_nova, extensions.gen_salt('bf')), updated_at = now()
    where id = cid;
end $$;

-- Excluir família: também remove as contas de login (pais e criança)
create or replace function excluir_familia() returns void
language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  select familia_id into fid from perfis where user_id = auth.uid() limit 1;
  if fid is not null then
    delete from auth.users where id in (select user_id from perfis where familia_id = fid and user_id is not null);
    delete from familias where id = fid;
  end if;
end $$;

-- Um usuário pertence a uma família só
create unique index if not exists perfis_user_unico on perfis(user_id) where user_id is not null;
